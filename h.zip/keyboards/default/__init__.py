from .zodiac_btn import  langs
